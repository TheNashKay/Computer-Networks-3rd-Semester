# Robustness extension notes

## What changed
- Added a sixth dynamic-routing experiment with 60 requests (30 from each client).
- A background thread changes server path delay at random elapsed-time intervals, and sometimes marks a server unavailable, stops its process, then restarts and re-enables it.
- Clients retry a request up to three times after transient connection or response errors, using a short increasing delay between attempts.
- Response time for a successful retried request includes time spent on earlier failed attempts and retry waits.
- Failed-after-retry requests are recorded in results.csv and counted separately in summary.json instead of stopping the entire experiment.

## Running in the existing VM
From the VM, copy the shared-folder copy into the project directory, then run:

    cp -r /media/sf_scds/robust_version ~/scds/
    cd ~/scds/robust_version
    ./run_demo.sh

The script uses `../.venv` from the existing `~/scds` project when the improved folder has no private virtual environment. It still needs sudo to create Mininet namespaces and switches; enter the VM password when prompted.

The random run has no single fixed expected output. Save the terminal output plus the generated CSV, summary JSON, and controller log after the run. The controller is informed of availability changes by the experiment driver; this extension does not implement autonomous server health checks.
